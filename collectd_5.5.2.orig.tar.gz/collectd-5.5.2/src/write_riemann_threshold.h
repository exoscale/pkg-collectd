#ifndef WRITE_RIEMANN_THRESHOLD_H
#define WRITE_RIEMANN_THRESHOLD_H

int write_riemann_threshold_check(const data_set_t *, const value_list_t *, int *);

#endif
